
import React from 'react';

const AboutUsPage: React.FC = () => {
  return (
    <section id="about" className="relative py-16 md:py-24 bg-cover bg-center" style={{ backgroundImage: "url('https://picsum.photos/seed/lightbg/1920/1080')" }}>
      <div className="absolute inset-0 bg-brand-light bg-opacity-80 backdrop-blur-sm"></div>
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto bg-white/70 backdrop-blur-md rounded-lg shadow-2xl overflow-hidden">
          <div className="p-8 md:p-12">
            <h2 className="text-3xl md:text-4xl font-bold text-brand-dark mb-6 font-serif text-center">
              Welcome to MFS Exports
            </h2>
            <div className="space-y-6 text-brand-primary text-base md:text-lg leading-relaxed font-light">
              <p>
                Welcome to Metric Flux Solutions, a leading cashew manufacturer and exporter based in the heart of Kerala, India. We specialize in producing high-quality, 100% natural cashew nuts for domestic and international markets.
              </p>
              <p>
                Our commitment is to provide our clients with the finest quality cashews, carefully processed and packaged to meet global standards. With a focus on sustainability and ethical practices, we ensure every batch maintains the rich taste and nutritional value that our region's cashews are famous for.
              </p>
              <p>
                We offer flexible order quantities starting from 500kg, making us the ideal partner for businesses looking for reliable bulk cashew exports.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUsPage;
