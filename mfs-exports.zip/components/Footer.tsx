
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-blue-dark text-white">
      <div className="container mx-auto px-6 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center text-center md:text-left">
          <div className="mb-4 md:mb-0">
            <h3 className="text-xl font-bold font-serif">MFS EXPORTS</h3>
            <p className="text-sm text-gray-300">Premium Cashew Exporters</p>
          </div>
          <div className="flex space-x-6 mb-4 md:mb-0">
            <a href="#" className="inline-block transform hover:-translate-y-0.5 transition-all duration-300 ease-in-out hover:text-gray-300">Quick Links</a>
            <a href="#" className="inline-block transform hover:-translate-y-0.5 transition-all duration-300 ease-in-out hover:text-gray-300">Terms & Conditions</a>
            <a href="#" className="inline-block transform hover:-translate-y-0.5 transition-all duration-300 ease-in-out hover:text-gray-300">Privacy Policy</a>
          </div>
        </div>
        <div className="mt-8 pt-6 border-t border-brand-blue-hover text-center text-sm text-gray-300">
          <p>&copy; {new Date().getFullYear()} MFS EXPORTS. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;