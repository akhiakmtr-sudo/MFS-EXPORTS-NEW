import React from 'react';

const products = [
  {
    name: "W180 Cashew",
    description: "Large sized cashews, often called 'Jumbo' nuts. 180-200 nuts per pound. Perfect for premium snacks and gift packages.",
    imageUrl: "https://i.postimg.cc/1t8hSQws/w180-whole-cashew-nuts-1734068178-7735420.jpg"
  },
  {
    name: "W240 Cashew",
    description: "Popular size known for its great value. 240-260 nuts per pound. Excellent for cooking and everyday snacking.",
    imageUrl: "https://i.postimg.cc/pX3Lmsq2/w-240-cashew-nut-500x500.jpg"
  },
  {
    name: "W320 Cashew",
    description: "The most common trading grade. 300-320 nuts per pound. Versatile size for various culinary uses.",
    imageUrl: "https://i.postimg.cc/CL5RBB04/img-20211225-wa0002-1000x1000.jpg"
  },
  {
    name: "W450 Cashew",
    description: "Smaller size, 450-500 nuts per pound. Economical choice for processing, confectionery, and recipes.",
    imageUrl: "https://i.postimg.cc/3NHZrXV9/w450-cashew-nut-1000x1000.jpg"
  },
  {
    name: "JH Split Cashew",
    description: "Cashews that are naturally split during processing. Ideal for toppings, mixes, and food manufacturing.",
    imageUrl: "https://i.postimg.cc/kgwYjpzC/w240-cashews-500x500.jpg"
  },
  {
    name: "LWP Cashew",
    description: "Light White Pieces. Uniformly sized broken pieces for baking, cooking, and industrial use.",
    imageUrl: "https://i.postimg.cc/1tdHxxrx/lwp-cashew-nut-500x500.jpg"
  },
  {
    name: "BB Broken Cashew",
    description: "Baby Broken pieces. Cost-effective option for grinding into paste, sauces, and desserts.",
    imageUrl: "https://i.postimg.cc/7YV4ktNV/broken-cashew-nuts-1000x1000.jpg"
  },
  {
    name: "Masala Cashew",
    description: "Our specialty spiced cashews. Flavored with a blend of traditional Indian spices for a delicious snack.",
    imageUrl: "https://i.postimg.cc/zG8fwRxd/red-chilli-masala-cashew-1000x1000.jpg"
  }
];

const ProductsPage: React.FC = () => {
  return (
    <section id="products" className="bg-brand-light py-16 md:py-24">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-brand-dark mb-4 font-serif">Our Products</h2>
          <p className="text-lg text-brand-primary max-w-3xl mx-auto">
            We offer a wide range of premium quality cashew nuts, processed to perfection. Explore our main variants below.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <div key={product.name} className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:scale-105 hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 ease-in-out flex flex-col">
              <img src={product.imageUrl} alt={product.name} className="w-full aspect-square object-cover" />
              <div className="p-6 flex flex-col flex-grow">
                <h3 className="text-xl font-bold text-brand-primary mb-3 font-serif">{product.name}</h3>
                <p className="text-brand-primary flex-grow">{product.description}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="text-center mt-16">
          <a
            href="https://wa.me/918088613895?text=I'm%20interested%20in%20learning%20more%20about%20your%20cashew%20variants."
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-brand-secondary text-white font-bold py-3 px-8 rounded-full text-lg hover:bg-brand-primary transition-colors duration-300 shadow-lg"
          >
            More Variants
          </a>
        </div>
      </div>
    </section>
  );
};

export default ProductsPage;