
import React, { useState } from 'react';
import PhoneIcon from './icons/PhoneIcon';
import MailIcon from './icons/MailIcon';
import LocationIcon from './icons/LocationIcon';
import GstIcon from './icons/GstIcon';

const ContactUsPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    mobile: '',
    queries: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Thank you, ${formData.name}! Your query has been sent.`);
    console.log(formData);
    // Reset form
    setFormData({ name: '', email: '', mobile: '', queries: '' });
  };

  return (
    <section id="contact" className="bg-brand-light py-16 md:py-24">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-brand-dark mb-4 font-serif">Contact Us</h2>
          <p className="text-lg text-brand-primary max-w-3xl mx-auto">
            Reach out to us for quotes, samples, or any questions about our premium cashew products.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-12 lg:gap-16">
          {/* Contact Info */}
          <div className="lg:w-1/3 space-y-8">
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 bg-brand-accent p-3 rounded-full"><PhoneIcon /></div>
              <div>
                <h3 className="text-xl font-semibold text-brand-primary">Phone</h3>
                <p className="text-brand-primary">+91 8088613895</p>
                <p className="text-brand-primary">+91 9946002313</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 bg-brand-accent p-3 rounded-full"><MailIcon /></div>
              <div>
                <h3 className="text-xl font-semibold text-brand-primary">Email</h3>
                <p className="text-brand-primary">info@metricfluxsolutions.com</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 bg-brand-accent p-3 rounded-full"><LocationIcon /></div>
              <div>
                <h3 className="text-xl font-semibold text-brand-primary">Address</h3>
                <p className="text-brand-primary">46/A1, Ground floor, Mattannur, Kannur, Kerala - 670702</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 bg-brand-accent p-3 rounded-full"><GstIcon /></div>
              <div>
                <h3 className="text-xl font-semibold text-brand-primary">GST Number</h3>
                <p className="text-brand-primary">32CXGPA2995F1ZN</p>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:w-2/3 bg-white p-8 rounded-lg shadow-xl border-t-4 border-brand-secondary">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-brand-primary mb-1">Name</label>
                <input type="text" name="name" id="name" required value={formData.name} onChange={handleInputChange} className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-brand-secondary focus:border-brand-secondary" />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-brand-primary mb-1">Email ID</label>
                <input type="email" name="email" id="email" required value={formData.email} onChange={handleInputChange} className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-brand-secondary focus:border-brand-secondary" />
              </div>
              <div>
                <label htmlFor="mobile" className="block text-sm font-medium text-brand-primary mb-1">Mobile Number</label>
                <input type="tel" name="mobile" id="mobile" required value={formData.mobile} onChange={handleInputChange} className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-brand-secondary focus:border-brand-secondary" />
              </div>
              <div>
                <label htmlFor="queries" className="block text-sm font-medium text-brand-primary mb-1">Queries</label>
                <textarea name="queries" id="queries" rows={4} required value={formData.queries} onChange={handleInputChange} className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-brand-secondary focus:border-brand-secondary"></textarea>
              </div>
              <div>
                <button type="submit" className="w-full bg-brand-secondary text-white font-bold py-3 px-6 rounded-md hover:bg-brand-primary transition-colors duration-300 shadow-md">
                  Send Message
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactUsPage;