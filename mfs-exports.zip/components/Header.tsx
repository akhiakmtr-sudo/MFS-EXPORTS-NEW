
import React, { useState, useEffect } from 'react';
import MenuIcon from './icons/MenuIcon';
import CloseIcon from './icons/CloseIcon';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleNavClick = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isMenuOpen]);

  const navLinks: { id: string; label: string }[] = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About Us' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'products', label: 'Our Services' },
    { id: 'contact', label: 'Contact Us' },
  ];

  return (
    <header className="sticky top-0 bg-brand-blue-dark/80 backdrop-blur-sm shadow-md z-50 text-white">
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <div className="flex-1"></div>
        <div className="flex-1 text-center">
            <h1 
                onClick={() => handleNavClick('home')}
                className="text-2xl md:text-3xl font-bold tracking-wider font-serif cursor-pointer text-white transition-opacity duration-300 hover:opacity-80">
                MFS EXPORTS
            </h1>
        </div>
        <div className="flex-1 flex justify-end">
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-2 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-accent"
            aria-label="Open Menu"
          >
            <MenuIcon />
          </button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity duration-300 ${
          isMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setIsMenuOpen(false)}
      ></div>
      <div
        className={`fixed top-0 right-0 h-full w-72 bg-brand-blue-dark shadow-xl z-50 transform transition-transform duration-300 ease-in-out ${
          isMenuOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex justify-end p-4">
          <button 
            onClick={() => setIsMenuOpen(false)} 
            className="p-2 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-accent" 
            aria-label="Close Menu">
            <CloseIcon />
          </button>
        </div>
        <nav className="flex flex-col p-6 space-y-4">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleNavClick(link.id)}
              className="text-lg text-white text-left py-2 px-4 rounded-md hover:bg-brand-blue-hover hover:translate-x-2 transform transition-all duration-300 ease-in-out"
            >
              {link.label}
            </button>
          ))}
        </nav>
      </div>
    </header>
  );
};

export default Header;