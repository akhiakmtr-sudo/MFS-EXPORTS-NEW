import React from 'react';

const HomePage: React.FC = () => {
  return (
    <section
      id="home"
      className="relative h-screen bg-cover bg-center bg-no-repeat flex items-center justify-center text-white"
      style={{ backgroundImage: "url('https://i.postimg.cc/3wx86zwF/Cashews.jpg')" }}
    >
      <div className="absolute inset-0 bg-black opacity-50"></div>
      <div className="relative z-10 text-center p-8 max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-6xl font-bold mb-4 font-serif leading-tight tracking-wide">
          Experience the Finest Quality Cashews from Kerala
        </h1>
        <p className="text-lg md:text-2xl font-light text-gray-200">
          100% Natural, Sustainably Sourced, and Exported Worldwide.
        </p>
      </div>
    </section>
  );
};

export default HomePage;