
import React from 'react';

const galleryImages = [
  { imageUrl: 'https://i.postimg.cc/tJnCkc5C/AQMlvb0-Rnt-F5n6f9a-Cocx-Gzh3-UQWLQ8rt-Wx-Ge-Knhk-Xnpa-O7-Nf7u-PIHi-Eqs-SS5f-VNXtt-JG1kpff8gnl7a-Ed-XG1s-BQv-Js58-Fj-Yt0-DP.jpg', alt: 'Cashew processing plant' },
  { imageUrl: 'https://i.postimg.cc/X7ypkrHc/AQMq8-I-kl-U5-Nda-FML48-EGYZtr-WUw-Du2-Au-Pwg5r9a-UDmrv-A58-Noq-QNDD7-u-R3xx-GF5-ASQq-RB46-Zp-Gv-Hpmx-JWg2-F-JANWY2-Qr-NX502.jpg', alt: 'Lush cashew farm in Kerala' },
  { imageUrl: 'https://i.postimg.cc/K8PjCdy1/AQN2qjk-Ui-X0f-TNJ07i-R-Wx-BUCPw-Y6bx4-Z8-Qepg-Ig-c-d-MEwh-CDV-GSx9ek8-Apr-Nrb-Oz-J8z0-I6-XUVr6e-R7-Mj-Ul-GGQUIuon1-Gf-I.jpg', alt: 'Workers carefully sorting cashews' },
  { imageUrl: 'https://i.postimg.cc/rmmp0sR4/AQNq-Kxqr-i-Tn-K2-8-O9h-SJz-Azw-JLDw-Op-WFLjga-M7-B9f6-w1-Yo-KTEQqx-FDGqh-ERYYljz-LMi0m-XDm-O77sxm-DQGa7rg-OXKRXpz-RGAC3-S.jpg', alt: 'Cashews being packaged for export' },
  { imageUrl: 'https://i.postimg.cc/7Z8bsqjv/AQOFr-OXIe852g-t-Txmlf-TRbw-Hhj-EEHU5xh-MG0k8ex-z-Rok-Hp-Y4-OJvj-Xl-UEB039-Ed-Rcgc-ZJjws-Qc-XSPoyt-KJGv-HTBVkktvhe-BKPn2.jpg', alt: 'A bowl of freshly roasted cashews' },
  { imageUrl: 'https://i.postimg.cc/26KS4YnK/cashew-slider.jpg', alt: 'Beautiful scenery of Kerala backwaters' },
];

const GalleryPage: React.FC = () => {
  return (
    <section id="gallery" className="bg-white py-16 md:py-24">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-brand-dark mb-4 font-serif">Our Gallery</h2>
          <p className="text-lg text-brand-primary max-w-3xl mx-auto">
            A glimpse into our process, from the lush farms of Kerala to our state-of-the-art processing facilities.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {galleryImages.map((image, index) => (
            <div key={index} className="group overflow-hidden rounded-lg shadow-lg cursor-pointer">
              <img 
                src={image.imageUrl} 
                alt={image.alt} 
                className="w-full h-full aspect-video object-cover transform group-hover:scale-110 transition-transform duration-500 ease-in-out" 
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default GalleryPage;
