
export type Page = 'home' | 'about' | 'products' | 'contact';
