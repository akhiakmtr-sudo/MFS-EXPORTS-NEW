
import React from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './components/HomePage';
import AboutUsPage from './components/AboutUsPage';
import GalleryPage from './components/GalleryPage';
import ProductsPage from './components/ProductsPage';
import ContactUsPage from './components/ContactUsPage';
import WhatsAppButton from './components/WhatsAppButton';
import FadeInSection from './components/FadeInSection';

const App: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col font-sans bg-brand-light text-brand-dark">
      <Header />
      <main>
        <FadeInSection>
          <HomePage />
        </FadeInSection>
        <FadeInSection>
          <AboutUsPage />
        </FadeInSection>
        <FadeInSection>
          <GalleryPage />
        </FadeInSection>
        <FadeInSection>
          <ProductsPage />
        </FadeInSection>
        <FadeInSection>
          <ContactUsPage />
        </FadeInSection>
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
  );
};

export default App;